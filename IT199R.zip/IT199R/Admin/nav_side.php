<!--==================================Sidenav============================ -->
<nav class="navbar-primary" style="height: 100%;">
<a href="#" class="btn-expand-collapse"><span class="glyphicon glyphicon-menu-left"></span></a>

<ul class="navbar-primary-menu">
<li>
  <a href="home.php"><span class="glyphicon glyphicon-home"></span><span class="nav-label"> Home</span></a>

  <a href="accounts.php"><span class="glyphicon glyphicon-user"></span><span class="nav-label">User Accounts</span></a>

   <a href="mobile.php"><span class="glyphicon glyphicon-phone"></span><span class="nav-label">Mobile</span></a>

  <a href="search.php"><span class="glyphicon glyphicon-search"></span><span class="nav-label">IN /OUT<span></a>

  <a href="announcements.php"><span class="glyphicon glyphicon-bullhorn"></span><span class="nav-label">Announcement<span></a>

  <a href="messages.php"><span class="glyphicon glyphicon-envelope"></span><span class="nav-label">Message<span></a>

  <a href="reports.php"><span class="glyphicon glyphicon-list-alt"></span><span class="nav-label">Reports</span></a>

  <a href="csv.php"><span class="glyphicon glyphicon-file"></span><span class="nav-label">CSV</span></a>

  <a href="test_environment.php"><span class="glyphicon glyphicon-wrench"></span><span class="nav-label"> Testing Portal</span></a>
</li>
</ul>
</nav>
