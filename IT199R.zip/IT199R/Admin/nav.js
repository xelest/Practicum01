$('.btn-expand-collapse').click(function(e) {
        $('.navbar-primary').toggleClass('collapsed');
});