<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title></title>
  <!-- REQUIRED HEADERS -->
  <?php include 'phpcore/include_headers.php' ?>
</head>
<body>
<!-- BODY -->

<!-- REQUIRED SCRIPTS -->
<?php include 'phpcore/include_scripts.php' ?>
</body>
</html>
